=== Snipers FSE ===
Contributors: gracethemes
Tags:blog, entertainment, education, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.3
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Snipers FSE is a free motivational speaker WordPress theme for advisor, business coach, company, corporate, firm, gutenberg, life coach, personal development, portfolio. It is a powerful and responsive life and business coaching WordPress theme, for today�s professional life coach, business advisor, consultant or agency. This multipurpose theme is also suitable for corporate, business, construction, hotel, restaurant, flower shop, travel and tour website, coaching, education, sports, medical, doctor, gym, fitness, modelling, wedding. The Snipers FSE theme is coded with HTML5 and has an amazingly attractive outlook. The overall appearance of this theme is elegant and classy, looking to impress your viewers greatly. The homepage of this free WordPress theme is more attractive than any other theme. Every element of this WordPress theme is customizable. This WordPress theme is multilingual and translation ready. The Snipers FSE theme is also SEO optimized. This free motivational speaker WordPress Theme is highly compatible with other popular builder plugins as well. For instance, the WPForms builder plugin, Accordions builder plugin, Sliders, BuddyPress forms, and NextGen Gallery are all perfectly integrated with the Snipers FSE theme.

== Theme License & Copyright == 

* Snipers FSE WordPress Theme, Copyright 2023 Grace Themes 
* Snipers FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

= 1.1 =
* example email address added
* index.php file removed
* added url / license of image and icons



== Resources ==

Theme is Built using the following resource bundles.

= jQuery Nivo Slider =
* Name of Author: Dev7studios
* Copyright: 2010-2012
* https://github.com/Codeinwp/Nivo-Slider-jQuery
* License: MIT License
* https://github.com/Codeinwp/Nivo-Slider-jQuery/blob/master/license.txt


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/807119 ( Header Banner image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/597846 (welcome right image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/600729 (Who we are Left image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1335775 (Ball image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/714078 (small image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1335775 (Ball image)

= Icon Images =

  * Grace Themes Self Designed icons images:

	assets/images/icon-emailus.png
	assets/images/icon-map.png
	assets/images/foot-icon-email.png
	assets/images/foot-icon-map.png
	assets/images/foot-icon-phone.png


     
For any help you can mail us at support@gracethemes.com