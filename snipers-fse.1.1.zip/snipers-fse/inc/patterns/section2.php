<?php
/**
 * Welcome Section
 */
return array(
	'title'      => esc_html__( 'Welcome Section', 'snipers-fse' ),
	'categories' => array( 'snipers-fse', 'Welcome Section' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","right":"var:preset|spacing|50","left":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}},"color":{"background":"#f6f6f6"}},"layout":{"type":"default"}} -->
<div class="wp-block-group has-background" style="background-color:#f6f6f6;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0"><!-- wp:column {"width":"45%","style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:45%"><!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.1","fontStyle":"normal","fontWeight":"500","fontSize":"22px","textTransform":"uppercase","letterSpacing":"1px"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}},"textColor":"primary","fontFamily":"teko"} -->
<h5 class="wp-block-heading has-primary-color has-text-color has-teko-font-family" style="margin-bottom:var(--wp--preset--spacing--40);font-size:22px;font-style:normal;font-weight:500;letter-spacing:1px;line-height:1.1;text-transform:uppercase">WELCOME TO SNIPERS</h5>
<!-- /wp:heading -->

<!-- wp:heading {"style":{"typography":{"fontSize":"60px","lineHeight":"1.0","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#222222"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"className":"About-head","fontFamily":"teko"} -->
<h2 class="wp-block-heading About-head has-text-color has-teko-font-family" style="color:#222222;margin-bottom:var(--wp--preset--spacing--60);font-size:60px;font-style:normal;font-weight:600;line-height:1.0">One Nation, One Team,<br>One Dream.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|70"}}}} -->
<p style="margin-bottom:var(--wp--preset--spacing--70)">Sed eu justo sit amet metus laoreet accumsanis asce<br>ayli quam, cc umsausce ayli quam, tellus id inumsau<br>sce asad uam, tellus wcid in aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50"},"blockGap":"0","margin":{"top":"0","bottom":"var:preset|spacing|70"}},"border":{"radius":"10px"}},"backgroundColor":"foreground","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-foreground-background-color has-background" style="border-radius:10px;margin-top:0;margin-bottom:var(--wp--preset--spacing--70);padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"},"blockGap":{"top":"0","left":"var:preset|spacing|20"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"40px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontFamily":"teko"} -->
<h3 class="wp-block-heading has-text-align-center has-teko-font-family" style="margin-top:0;margin-bottom:0;font-size:40px;font-style:normal;font-weight:600">30</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontSize":"small","fontFamily":"teko"} -->
<h5 class="wp-block-heading has-text-align-center has-teko-font-family has-small-font-size" style="margin-top:0;margin-bottom:0;font-style:normal;font-weight:500">Experience</h5>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"40px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontFamily":"teko"} -->
<h3 class="wp-block-heading has-text-align-center has-teko-font-family" style="margin-top:0;margin-bottom:0;font-size:40px;font-style:normal;font-weight:600">100+</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontSize":"small","fontFamily":"teko"} -->
<h5 class="wp-block-heading has-text-align-center has-teko-font-family has-small-font-size" style="margin-top:0;margin-bottom:0;font-style:normal;font-weight:500">Team Members</h5>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"0"}}} -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"40px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontFamily":"teko"} -->
<h3 class="wp-block-heading has-text-align-center has-teko-font-family" style="margin-top:0;margin-bottom:0;font-size:40px;font-style:normal;font-weight:600">16</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"fontStyle":"normal","fontWeight":"500"},"spacing":{"margin":{"top":"0","bottom":"0"}}},"fontSize":"small","fontFamily":"teko"} -->
<h5 class="wp-block-heading has-text-align-center has-teko-font-family has-small-font-size" style="margin-top:0;margin-bottom:0;font-style:normal;font-weight:500">Expert Coach</h5>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary","textColor":"foreground","style":{"typography":{"fontSize":"22px","letterSpacing":"0.5px"},"spacing":{"padding":{"left":"var:preset|spacing|70","right":"var:preset|spacing|70","top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"fontFamily":"teko"} -->
<div class="wp-block-button has-custom-font-size has-teko-font-family" style="font-size:22px;letter-spacing:0.5px"><a class="wp-block-button__link has-foreground-color has-primary-background-color has-text-color has-background wp-element-button" style="padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--70)">Discover More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"3%"} -->
<div class="wp-block-column" style="flex-basis:3%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"52%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:52%"><!-- wp:image {"id":1677,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/SF-welcome-right.png" alt="" class="wp-image-1677"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);