<?php
/**
 * Default footer
 */
return array(
	'title'      => esc_html__( 'Default footer', 'snipers-fse' ),
	'categories' => array( 'snipers-fse', 'footer' ),
	'content'    => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"blockGap":"0"},"elements":{"link":{"color":{"text":"var:preset|color|white"}}},"color":{"background":"#171717"}},"textColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull has-white-color has-text-color has-background has-link-color" style="background-color:#171717;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","right":"var:preset|spacing|50","left":"var:preset|spacing|50"},"blockGap":"0"}},"className":"SF-footer-wrapper","layout":{"type":"default"}} -->
<div class="wp-block-group SF-footer-wrapper" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0","left":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30","top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)"><!-- wp:site-title {"level":2} /-->

<!-- wp:paragraph -->
<p>Sedeu justo sitamet metus laoreet velnisl. Suspendisse ut aliquet damacumsan.</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"customIconBackgroundColor":"#2d2d2d","iconBackgroundColorValue":"#2d2d2d","size":"has-normal-icon-size","style":{"spacing":{"margin":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"0","right":"0"},"blockGap":{"top":"0","left":"var:preset|spacing|30"},"padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"className":"is-style-default"} -->
<ul class="wp-block-social-links has-normal-icon-size has-icon-background-color is-style-default" style="margin-top:var(--wp--preset--spacing--60);margin-right:0;margin-bottom:var(--wp--preset--spacing--60);margin-left:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"twitter"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30","top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"0","right":"0","bottom":"var:preset|spacing|60","left":"0"}},"typography":{"fontSize":"26px","fontStyle":"normal","fontWeight":"500"}}} -->
<h2 class="wp-block-heading" style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--60);margin-left:0;font-size:26px;font-style:normal;font-weight:500">Company</h2>
<!-- /wp:heading -->

<!-- wp:list {"style":{"spacing":{"padding":{"left":"var:preset|spacing|40"}},"typography":{"lineHeight":"2"}}} -->
<ul style="padding-left:var(--wp--preset--spacing--40);line-height:2"><!-- wp:list-item -->
<li>Home</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Services</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Pages</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Players</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Blog</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>League</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"right":"var:preset|spacing|30","left":"var:preset|spacing|30","top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"0","right":"0","bottom":"var:preset|spacing|60","left":"0"}},"typography":{"fontSize":"26px","fontStyle":"normal","fontWeight":"500"}}} -->
<h2 class="wp-block-heading" style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--60);margin-left:0;font-size:26px;font-style:normal;font-weight:500">Essential Links</h2>
<!-- /wp:heading -->

<!-- wp:list {"style":{"spacing":{"padding":{"left":"var:preset|spacing|40"}},"typography":{"lineHeight":"2"}}} -->
<ul style="padding-left:var(--wp--preset--spacing--40);line-height:2"><!-- wp:list-item -->
<li>Sponsors</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Board Management</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Match Fixtures</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Club Rankings</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Awards</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Upcoming Events</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"left":"var:preset|spacing|30","right":"var:preset|spacing|30","top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-column" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--30)"><!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|60"}},"typography":{"fontSize":"26px","fontStyle":"normal","fontWeight":"500"}}} -->
<h3 class="wp-block-heading" style="margin-bottom:var(--wp--preset--spacing--60);font-size:26px;font-style:normal;font-weight:500">Get In Touch</h3>
<!-- /wp:heading -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"var:preset|spacing|50","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"var:preset|spacing|50"},"border":{"top":{"width":"0px","style":"none"},"right":{"width":"0px","style":"none"},"bottom":{"color":"#2e2e2e","width":"1px"},"left":{"width":"0px","style":"none"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="border-top-style:none;border-top-width:0px;border-right-style:none;border-right-width:0px;border-bottom-color:#2e2e2e;border-bottom-width:1px;border-left-style:none;border-left-width:0px;margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:var(--wp--preset--spacing--50);padding-left:0"><!-- wp:image {"id":1784,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/foot-icon-map.png" alt="" class="wp-image-1784"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<p style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0">USA California 20 first<br>Avenue, United State</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"var:preset|spacing|50"},"border":{"top":{"width":"0px","style":"none"},"right":{"width":"0px","style":"none"},"bottom":{"color":"#2e2e2e","width":"1px"},"left":{"width":"0px","style":"none"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="border-top-style:none;border-top-width:0px;border-right-style:none;border-right-width:0px;border-bottom-color:#2e2e2e;border-bottom-width:1px;border-left-style:none;border-left-width:0px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:0;padding-bottom:var(--wp--preset--spacing--50);padding-left:0"><!-- wp:image {"id":1796,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/foot-icon-phone.png" alt="" class="wp-image-1796"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<p style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0">123 456 7890</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|20","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"var:preset|spacing|50"},"dimensions":{"minHeight":"0px"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="min-height:0px;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--50);padding-right:0;padding-bottom:var(--wp--preset--spacing--20);padding-left:0"><!-- wp:image {"id":1798,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/foot-icon-email.png" alt="" class="wp-image-1798"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<p style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0">test@example.com</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","right":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|60"},"blockGap":"0","margin":{"top":"0","bottom":"0"}},"color":{"background":"#1b1b1b"}},"className":"SF-copy-wrap","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull SF-copy-wrap has-background" style="background-color:#1b1b1b;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--60)"><!-- wp:group {"style":{"spacing":{"blockGap":"0"}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"border":{"radius":"0px"},"spacing":{"padding":{"top":"0"}}}} -->
<div class="wp-block-columns" style="border-radius:0px;padding-top:0"><!-- wp:column {"style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"bottom":"0"}}}} -->
<p class="has-text-align-center" style="margin-bottom:0">@ Copyright 2023 Snipers FSE. All Rights Reserved. Design by <a rel="noreferrer noopener" href="https://gracethemes.com/" target="_blank">Grace Themes</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);