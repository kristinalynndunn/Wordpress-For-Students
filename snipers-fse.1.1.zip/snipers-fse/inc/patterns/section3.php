<?php
/**
 * Who We Are
 */
return array(
	'title'      => esc_html__( 'Who We Are', 'snipers-fse' ),
	'categories' => array( 'snipers-fse', 'Who We Are' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"backgroundColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group has-foreground-background-color has-background" style="padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"width":"39%","style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"blockGap":"0"}},"className":"sec3-LeftBX"} -->
<div class="wp-block-column sec3-LeftBX" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:39%"><!-- wp:image {"id":1718,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"20px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/who-we-are-left.jpg" alt="" class="wp-image-1718" style="border-radius:20px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"3%","style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"blockGap":"0"}},"className":"sec3-LeftBX"} -->
<div class="wp-block-column sec3-LeftBX" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:3%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"58%","style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}}},"className":"sec3-RightBX"} -->
<div class="wp-block-column sec3-RightBX" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:58%"><!-- wp:heading {"textAlign":"left","level":5,"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30","top":"0"}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"29px"}},"textColor":"primary","fontFamily":"teko"} -->
<h5 class="wp-block-heading has-text-align-left has-primary-color has-text-color has-teko-font-family" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--30);font-size:29px;font-style:normal;font-weight:500">Who we are</h5>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"left","level":3,"style":{"typography":{"fontSize":"60px","fontStyle":"normal","fontWeight":"600","lineHeight":"1.0"},"spacing":{"margin":{"bottom":"var:preset|spacing|60","top":"0","right":"0"}}},"fontFamily":"teko"} -->
<h3 class="wp-block-heading has-text-align-left has-teko-font-family" style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--60);font-size:60px;font-style:normal;font-weight:600;line-height:1.0">Growing Your Skill and<br>Rise Together</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"0","left":"0","top":"0","bottom":"var:preset|spacing|70"}}}} -->
<p style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--70);margin-left:0">Sed eu justo sit amet metus laoreet accumsanis asce ayli quaumsau<br>sce ayli quam, tellus id inumsau sce asad uam, tellus wcid in aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":{"top":"0","left":"var:preset|spacing|50"}},"border":{"radius":"0px"}}} -->
<div class="wp-block-columns" style="border-radius:0px;margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"className":"sec3-2colbx"} -->
<div class="wp-block-column sec3-2colbx" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"color":{"background":"#f6f6f6"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"},"border":{"radius":"15px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:15px;background-color:#f6f6f6;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"align":"center","id":2115,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/skill-icon01.jpg" alt="" class="wp-image-2115"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"30px","fontStyle":"normal","fontWeight":"500","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"var:preset|spacing|40","top":"var:preset|spacing|50"}}},"fontFamily":"teko"} -->
<h4 class="wp-block-heading has-text-align-center has-teko-font-family" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--40);font-size:30px;font-style:normal;font-weight:500;text-transform:uppercase">Sporting Wheel</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0">laoreet accumsanis asce<br>ayli quaum sausce aylqu<br>am, tellus inumsau.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}},"className":"sec3-2colbx"} -->
<div class="wp-block-column sec3-2colbx" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"color":{"background":"#f6f6f6"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"},"border":{"radius":"15px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-background" style="border-radius:15px;background-color:#f6f6f6;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)"><!-- wp:image {"align":"center","id":2116,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image aligncenter size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/skill-icon02.jpg" alt="" class="wp-image-2116"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"30px","fontStyle":"normal","fontWeight":"500","textTransform":"uppercase"},"spacing":{"margin":{"bottom":"var:preset|spacing|40","top":"var:preset|spacing|50"}}},"fontFamily":"teko"} -->
<h4 class="wp-block-heading has-text-align-center has-teko-font-family" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--40);font-size:30px;font-style:normal;font-weight:500;text-transform:uppercase">Sporting Ball</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0">laoreet accumsanis asce<br>ayli quaum sausce aylqu<br>am, tellus inumsau.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);