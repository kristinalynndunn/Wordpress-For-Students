<?php
/**
 * Add Theme info Page
 */

function snipers_fse_menu() {
	add_theme_page( esc_html__( 'Snipers FSE', 'snipers-fse' ), esc_html__( 'About Snipers FSE', 'snipers-fse' ), 'edit_theme_options', 'about-snipers-fse', 'snipers_fse_theme_page_display' );
}
add_action( 'admin_menu', 'snipers_fse_menu' );

function snipers_fse_admin_theme_style() {
	wp_enqueue_style('snipers-fse-custom-admin-style', esc_url(get_template_directory_uri()) . '/assets/css/admin-styles.css');
}
add_action('admin_enqueue_scripts', 'snipers_fse_admin_theme_style');

/**
 * Display About page
 */
function snipers_fse_theme_page_display() {
	$theme = wp_get_theme();

	if ( is_child_theme() ) {
		$theme = wp_get_theme()->parent();
	} ?>

		<div class="Grace-wrapper">
			<div class="Grcae-info-holder">
				<div class="Grcae-info-holder-content">
					<div class="Grace-Welcome">
						<h1 class="welcomeTitle"><?php esc_html_e( 'About Theme Info', 'snipers-fse' ); ?></h1>                        
						<div class="featureDesc">
							<?php echo esc_html__( 'Snipers FSE theme is particularly designed for soccer clubs, soccer coaches, sportsmen, soccer players, and businessmen related to the sports industry.', 'snipers-fse' ); ?>
						</div>
						
                        <h1 class="welcomeTitle"><?php esc_html_e( 'Theme Features', 'snipers-fse' ); ?></h1>

                        <h2><?php esc_html_e( 'Block Compatibale', 'snipers-fse' ); ?></h2>
                        <div class="featureDesc">
                            <?php echo esc_html__( 'The built-in customizer panel quickly change aspects of the design and display changes live before saving them.', 'snipers-fse' ); ?>
                        </div>
                        
                        <h2><?php esc_html_e( 'Responsive Ready', 'snipers-fse' ); ?></h2>
                        <div class="featureDesc">
                            <?php echo esc_html__( 'The themes layout will automatically adjust and fit on any screen resolution and looks great on any device. Fully optimized for iPhone and iPad.', 'snipers-fse' ); ?>
                        </div>
                        
                        <h2><?php esc_html_e( 'Cross Browser Compatible', 'snipers-fse' ); ?></h2>
                        <div class="featureDesc">
                            <?php echo esc_html__( 'Our themes are tested in all mordern web browsers and compatible with the latest version including Chrome,Firefox, Safari, Opera, IE11 and above.', 'snipers-fse' ); ?>
                        </div>
                        
                        <h2><?php esc_html_e( 'E-commerce', 'snipers-fse' ); ?></h2>
                        <div class="featureDesc">
                            <?php echo esc_html__( 'Fully compatible with WooCommerce plugin. Just install the plugin and turn your site into a full featured online shop and start selling products.', 'snipers-fse' ); ?>
                        </div>

					</div> <!-- .Grace-Welcome -->
				</div> <!-- .Grcae-info-holder-content -->
				
				
				<div class="Grcae-info-holder-sidebar">
                        <div class="sidebarBX">
                            <h2 class="sidebarBX-title"><?php echo esc_html__( 'Get Strategist PRO', 'snipers-fse' ); ?></h2>
                            <p><?php echo esc_html__( 'More features availbale on Premium version', 'snipers-fse' ); ?></p>
                            <a href="<?php echo esc_url( 'https://gracethemes.com/themes/football-wordpress-theme/' ); ?>" target="_blank" class="button"><?php esc_html_e( 'Get the PRO Version &rarr;', 'snipers-fse' ); ?></a>
                        </div>


						<div class="sidebarBX">
							<h2 class="sidebarBX-title"><?php echo esc_html__( 'Important Links', 'snipers-fse' ); ?></h2>

							<ul class="themeinfo-links">
                                <li>
									<a href="<?php echo esc_url( 'https://gracethemesdemo.com/snipers/' ); ?>" target="_blank"><?php echo esc_html__( 'Demo Preview', 'snipers-fse' ); ?></a>
								</li>                               
								<li>
									<a href="<?php echo esc_url( 'https://gracethemesdemo.com/documentation/snipers/#homepage-lite' ); ?>" target="_blank"><?php echo esc_html__( 'Documentation', 'snipers-fse' ); ?></a>
								</li>
								
								<li>
									<a href="<?php echo esc_url( 'https://gracethemes.com/wordpress-themes/' ); ?>" target="_blank"><?php echo esc_html__( 'View Our Premium Themes', 'snipers-fse' ); ?></a>
								</li>
							</ul>
						</div>

						<div class="sidebarBX">
							<h2 class="sidebarBX-title"><?php echo esc_html__( 'Leave us a review', 'snipers-fse' ); ?></h2>
							<p><?php echo esc_html__( 'If you are satisfied with Snipers FSE, please give your feedback.', 'snipers-fse' ); ?></p>
							<a href="https://wordpress.org/support/theme/snipers-fse/reviews/" class="button" target="_blank"><?php esc_html_e( 'Submit a review', 'snipers-fse' ); ?></a>
						</div>

				</div><!-- .Grcae-info-holder-sidebar -->	

			</div> <!-- .Grcae-info-holder -->
		</div><!-- .Grace-wrapper -->
<?php } ?>